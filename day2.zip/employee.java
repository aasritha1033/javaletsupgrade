package com.company;

public class employee {
    int age;
    String name, city;
    public void display()
    {
        name="xyz";
        city="abc";
        age=20;
        System.out.println(name+""+age+""+city);
    }
}
