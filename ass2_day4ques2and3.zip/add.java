import java.util.Scanner;
public class add {
    public static void main(String[] args) {
        int[] arr = new int[5];
        int sum=0;
        Scanner s=new Scanner(System.in);
        System.out.println("enter the numbers");
        for(int i=0;i<5;i++) {
            arr[i] = s.nextInt();
            sum = sum + arr[i];
        }
        System.out.println("sum of the given elements:"+sum);
    }
}
