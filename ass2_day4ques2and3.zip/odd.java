public class odd {
    public static void main(String[] args) {
        int[] a= {2,3,4,5,6};
        for(int i =0;i<5;i++)
            if(a[i]%2!=0)
                System.out.println(a[i]);
    }
}
