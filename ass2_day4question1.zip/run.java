public class run {
    public static void main(String[] args) {
        int i;
        avenger[] avg = new avenger[5];
        for(i=0;i<5;i++)
        {
            avg[i]=new avenger();
        }

        for(i=0;i<5;i++)
        {
            avg[i].getDetails();
        }

        for(i=0;i<5;i++)
        {
            avg[i].displayDetails();
        }
    }
}
