package com.company;

public class Main {

    public static void main(String[] args) {
        game game=new game();
        game.initGame();
        game.play();
    }
}
